<?php
require_once 'config.php';
header('Content-Type: application/json');

if (mysqli_connect_errno()) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed", "details" => mysqli_connect_error()]);
    exit();
}
$sql = "SELECT id, user_name, rating, message, created_at FROM feedbacks ORDER BY created_at DESC";
$result = $conn->query($sql);

$feedbacks = [];
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $feedbacks[] = $row;
    }
}

echo json_encode($feedbacks);
$conn->close();
?>
